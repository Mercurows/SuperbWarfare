package com.github.mcmodderanchor.simplebedrockmodel.v1.client.handler;

import com.github.mcmodderanchor.simplebedrockmodel.v1.client.animation.IFPAnimationInstance;
import com.github.mcmodderanchor.simplebedrockmodel.v1.client.event.SwapItemWithOffHand;
import com.github.mcmodderanchor.simplebedrockmodel.v1.client.renderer.IFPGeoItemRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.RenderFrameEvent;
import net.neoforged.neoforge.client.event.RenderHandEvent;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

import java.util.Optional;

@EventBusSubscriber(Dist.CLIENT)
public class FirstPersonRenderHandler {

    private static int realSelectedSlot = -1;
    private static ItemStack realMainHand = ItemStack.EMPTY;

    private static boolean transitioning = false;

    private static IFPAnimationInstance activeInstance = null;
    private static IFPAnimationInstance previousInstance = null;

    private static ItemStack pendingTarget = ItemStack.EMPTY;

    private static long switchStartTime = 0L;
    private static long currentSheatheDuration = 0L;

    private static boolean lockVanilla = false;
    private static boolean nextIsCustom = false;

    private static boolean forceHandSwapFlag = false;

    @SubscribeEvent
    public static void onPlayerLoggedOut(ClientPlayerNetworkEvent.LoggingOut event) {
        // 离开游戏时重置客户端状态
        realSelectedSlot = -1;
        realMainHand = ItemStack.EMPTY;
        transitioning = false;
        activeInstance = null;
        previousInstance = null;
        pendingTarget = ItemStack.EMPTY;
        lockVanilla = false;
        nextIsCustom = false;
        forceHandSwapFlag = false;
    }


    @SubscribeEvent
    public static void onRenderHand(SwapItemWithOffHand event) {
        forceHandSwapFlag = true;
    }

    @SubscribeEvent
    public static void onClientTick(RenderFrameEvent.Pre event) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) return;

        int newSlot = player.getInventory().selected;
        ItemStack newMain = player.getMainHandItem();

        boolean slotChanged = newSlot != realSelectedSlot || forceHandSwapFlag;
        boolean itemChanged = !isSameItemStacks(realMainHand, newMain);
        forceHandSwapFlag = false;

        realSelectedSlot = newSlot;
        realMainHand = newMain;

        if (slotChanged) {
            onSlotChanged(newMain);
        } else if (itemChanged) {
            onItemChangedInSameSlot(newMain);
        }if (activeInstance != null) {
            activeInstance.updateItem(newMain);
        }

        tickStates();
    }

    private static void onSlotChanged(ItemStack newStack) {
        pendingTarget = newStack;
        nextIsCustom = isCustomItem(newStack);

        if (transitioning) {
            return;
        }

        boolean oldIsCustom = activeInstance != null;

        previousInstance = activeInstance;
        activeInstance = createInstance(newStack);

        if (oldIsCustom) {
            // Custom → Any：播放 Putaway
            transitioning = true;
            lockVanilla = true;

            switchStartTime = System.currentTimeMillis();
            currentSheatheDuration = calculateSheatheDuration(previousInstance.currentItem());

            previousInstance.triggerPutAway();
        } else {
            // Vanilla → Custom / Vanilla：直接切
            transitioning = false;
            lockVanilla = false;
        }
    }

    private static void onItemChangedInSameSlot(ItemStack newStack) {
        pendingTarget = newStack;
        nextIsCustom = isCustomItem(newStack);

        if (transitioning) {
            return;
        }

        boolean oldIsCustom = activeInstance != null;

        previousInstance = activeInstance;
        activeInstance = createInstance(newStack);

        if (oldIsCustom) {
            transitioning = true;
            lockVanilla = true;

            switchStartTime = System.currentTimeMillis();
            currentSheatheDuration = calculateSheatheDuration(previousInstance.currentItem());

            previousInstance.triggerPutAway();
        } else {
            // Vanilla → Custom
            lockVanilla = false;
        }
    }

    private static void tickStates() {
        if (transitioning) {
            if (getSheatheProgress() >= 1.0f) {
                // Putaway 完成
                transitioning = false;
                lockVanilla = false;

                activeInstance = createInstance(pendingTarget);
                previousInstance = null;
            }
        }
    }

    @SubscribeEvent
    public static void tickAnimation(RenderFrameEvent.Pre event) {
        var ani = getActiveAnimationInstance();
        if (ani != null) {
            ani.triggerDraw();
            ani.tick(event.getPartialTick().getGameTimeDeltaPartialTick(true));
        }
    }

    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent event) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) return;

        IFPAnimationInstance inst = getActiveAnimationInstance();
        if (inst == null) return;

        ItemStack stack = inst.currentItem();
        if (stack.isEmpty()) return;

        getRenderer(stack).ifPresent(renderer -> {
            if (event.getHand() == InteractionHand.OFF_HAND) {
                if (renderer.blockOffhandRender()) {
                    event.setCanceled(true);
                }
                return;
            }

            ItemDisplayContext transformType;
            if (event.getHand() == InteractionHand.MAIN_HAND) {
                transformType = ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
            } else {
                transformType = ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
            }
            renderer.renderFirstPerson(
                    player,
                    stack,
                    transformType,
                    event.getPoseStack(),
                    event.getMultiBufferSource(),
                    event.getPackedLight(),
                    event.getPartialTick()
            );
            event.setCanceled(true);
        });
    }

    public static boolean shouldLockVanilla() {
        return lockVanilla;
    }


    public static float getTargetHeight() {
        return nextIsCustom ? 1.0F : 0.0F;
    }

    public static IFPAnimationInstance getActiveAnimationInstance() {
        return transitioning ? previousInstance : activeInstance;
    }

    private static IFPAnimationInstance createInstance(ItemStack stack) {
        return getRenderer(stack)
                .map(r -> r.createAnimationInstance(stack, Minecraft.getInstance().getCameraEntity()))
                .orElse(null);
    }

    private static boolean isCustomItem(ItemStack stack) {
        return getRenderer(stack).isPresent();
    }

    private static long calculateSheatheDuration(ItemStack stack) {
        return getRenderer(stack)
                .map(r -> r.getPutAwayDuration(stack))
                .orElse(0L);
    }

    private static float getSheatheProgress() {
        if (currentSheatheDuration <= 0) return 1.0f;
        long elapsed = System.currentTimeMillis() - switchStartTime;
        return Math.min(1.0f, (float) elapsed / currentSheatheDuration);
    }

    private static Optional<IFPGeoItemRenderer> getRenderer(ItemStack stack) {
        if (stack.isEmpty()) return Optional.empty();
        if (IClientItemExtensions.of(stack.getItem()).getCustomRenderer()
                instanceof IFPGeoItemRenderer renderer) {
            return Optional.of(renderer);
        }
        return Optional.empty();
    }

    private static boolean isSameItemStacks(ItemStack oldStack, ItemStack newStack) {
        if (oldStack == newStack) return true;
        if (oldStack.isEmpty() && newStack.isEmpty()) return true;
        if (oldStack.isEmpty() || newStack.isEmpty()) return false;

        return getRenderer(oldStack)
                .map(r -> r.isSameItem(oldStack, newStack))
                .orElseGet(() -> ItemStack.isSameItem(oldStack, newStack));
    }
}
